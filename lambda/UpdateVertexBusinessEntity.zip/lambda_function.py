import os
import json
import boto3
import botocore.config
import requests

# global variables  
MY_AWS_ACCESS_KEY = os.environ['MY_AWS_ACCESS_KEY']
MY_AWS_SECRET_ACCESS_KEY = os.environ['MY_AWS_SECRET_ACCESS_KEY']
MY_AWS_REGION = 'us-east-1'
tigergraph_apitoken_port = os.environ['tigergraph_apitoken_port']
tigergraph_apitoken_lifetime = os.environ['tigergraph_apitoken_lifetime']
tigergraph_ip = os.environ['tigergraph_ip']
tigergraph_graph_name = os.environ['tigergraph_graph_name']
tigergraph_secret = os.environ['tigergraph_secret']
s3_bucket = os.environ['s3_bucket']
s3_data_path = os.environ['s3_data_path']
s3_image_path = os.environ['s3_image_path']
should_end_session = True


""" this function opens a new s3 client """
def get_s3_conn():
    
    s3_conn = boto3.resource(
        's3',
        region_name=MY_AWS_REGION,
        aws_access_key_id=MY_AWS_ACCESS_KEY,
        aws_secret_access_key=MY_AWS_SECRET_ACCESS_KEY
    )
     
    return s3_conn
    
    
""" this function will get a new api token from TigerGraph """
def get_tg_auth_token() -> str:
    try:
        
        url = "{ip}:{port}/requesttoken?secret={secret}&lifetime={lt}".format(
            ip=tigergraph_ip,
            port=tigergraph_apitoken_port,
            secret=tigergraph_secret,
            lt=tigergraph_apitoken_lifetime
        )
                
        response = requests.get(url).json()

        return response['token']

    except Exception as e:
        print('Error getting authentication token from TigerGraph: {0}'.format(e))    


# kmlb 6.21.2020 http requests must use a NAT gateway. ensure that this lambda function
# is only attached to networks with a route table via the NAT gateway, not an internet gateway.
def lambda_handler(event, context):
    
    # open an s3 client connection
    s3_conn = get_s3_conn()
    
    # get the metadata file from s3
    try:
        s3_object = s3_conn.Object(s3_bucket, s3_data_path).get()
        payload = s3_object['Body']
    except Exception as e:
        print("Error getting metadata file from S3: {a}".format(a=e))
        return False 

    # set the request header and api token
    request_header = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer {0}'.format(get_tg_auth_token())
    }
        
    # upload the metadata
    try:
        url = "{ip}:{port}/graph/{graph}".format(
            ip=tigergraph_ip, 
            port=tigergraph_apitoken_port,
            graph=tigergraph_graph_name
        )
            
        response = requests.request("POST", url, headers=request_header, data=payload)

    except Exception as e:
        return_msg = e
    else:
        return_msg = "The vertex data was loaded successfully"
    finally:
        # build the response object
        json_resp = {
            "version": "1.0.0",
            "sessionAttributes": {
            "TigerGraph": "Load data"
            },
             "response": {
                 "outputSpeech": {
                    "type": "PlainText",
                    "text": return_msg,
                    "ssml": "<speak>" + return_msg + "</speak>"
                 },
                "card": {
                  "type": "Standard",
                  "title": tigergraph_graph_name,
                  "content": return_msg,
                  "text": return_msg,
                  "image": {
                    "smallImageUrl": "https://{0}.s3.amazonaws.com/{1}".format(s3_bucket, s3_image_path),
                    "largeImageUrl": "https://{0}.s3.amazonaws.com/{1}".format(s3_bucket, s3_image_path)
                  }
                },
                "reprompt": {
                  "outputSpeech": {
                    "type": "PlainText",
                    "text": "Plain text string to speak",
                    "ssml": "<speak>SSML text string to speak</speak>"
                  }
                },
                "shouldEndSession": should_end_session
            }
        }
            
        return json_resp            


